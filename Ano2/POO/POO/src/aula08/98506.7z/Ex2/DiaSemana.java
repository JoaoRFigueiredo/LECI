package aula08.Ex2;

public enum DiaSemana {
    segunda, terca, quarta, quinta, sexta, sabado, domingo
}
