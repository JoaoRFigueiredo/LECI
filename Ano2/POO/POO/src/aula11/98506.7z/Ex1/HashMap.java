package aula11.Ex1;

public class HashMap<T1, T2> {

}
