# LugWheels

## Grupo202

| Membros  | Nº mecanográfico |
| ------------- |:-------------:|
| João Figueiredo      | 98506     |
| Diana Marques     | 103231    |
| Guilherme Lopes    | 98393    |
| Luiz Brunet    | 91257    |

## Repositório Git

[Lugwheels](https://github.com/JoaoRFigueiredo/LugWheels/).

## Site da LugWheels
Aceder através deste [link](https://aswebsite-202.web.app/).

Começar por criar uma conta.