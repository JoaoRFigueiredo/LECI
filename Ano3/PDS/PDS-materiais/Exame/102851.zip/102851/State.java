public enum State {
    AVAILABLE, UNAVAILABLE
}
