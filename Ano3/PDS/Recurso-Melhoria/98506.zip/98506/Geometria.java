
public interface Geometria {
    public void draw();
    public boolean isValid();
}
