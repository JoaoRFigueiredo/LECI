# IHC_proj
2º Projeto de IHC


# How to run this project
- Have flutter installed on your computer
- Open a terminal inside ssd_frontend/ folder
- Type the following in the terminal
  - flutter run -d chrome
