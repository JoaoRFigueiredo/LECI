enum NavigationItem {
  perfil,
  ofertas,
  noticias,
  servicos,
  logout
}